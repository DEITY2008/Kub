package com.thepkub.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView web;
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback cb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        bindWifi();

        web = new WebView(this);
        web.setBackgroundColor(0xFF05070B);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                    .setMessage(msg)
                    .setPositiveButton("OK", (d, w) -> r.confirm())
                    .setNegativeButton("Cancel", (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel())
                    .show();
                return true;
            }
        });
        setContentView(web);
        // ใช้ origin เดียวกับบอร์ด (http://192.168.4.1) เพื่อให้ fetch('/d?..') ทำงานเหมือนเปิดจากบอร์ด
        web.loadDataWithBaseURL("http://192.168.4.1/", readAsset("index.html"),
                "text/html", "utf-8", null);
    }

    // บังคับให้ทราฟฟิกของแอปใช้ Wi-Fi Thepkub แม้ไม่มีอินเทอร์เน็ต (กัน Android สลับไปใช้เน็ตมือถือ)
    private void bindWifi() {
        try {
            cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkRequest req = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build();
            cb = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network n) { cm.bindProcessToNetwork(n); }
                @Override public void onLost(Network n) { cm.bindProcessToNetwork(null); }
            };
            cm.requestNetwork(req, cb);
        } catch (Exception ignored) { }
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            return o.toString("UTF-8");
        } catch (Exception e) { return "<h1>asset error</h1>"; }
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override public void onBackPressed() { /* กันเผลอกดออกขณะขับ */ }

    @Override
    protected void onDestroy() {
        try { if (cm != null && cb != null) { cm.bindProcessToNetwork(null); cm.unregisterNetworkCallback(cb); } }
        catch (Exception ignored) { }
        super.onDestroy();
    }
}
